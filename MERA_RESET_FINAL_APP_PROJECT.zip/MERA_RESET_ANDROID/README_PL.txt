MERA RESET — aplikacja Android dla Zestos DryFloat

CO ROBI APLIKACJA
- Uruchamia się jako normalna aplikacja z ikoną MERA RESET.
- Działa offline.
- Ekran gościa zawiera:
  1. DEEP FLOW — Feel the sound (wbudowany set)
  2. OCEAN RESONANCE — Slow down
  3. FLOATING PULSE — Move with the vibration
  4. THETA RESET — Quiet the mind · Headphones recommended
  5. SILENCE — No music · just float
- Sesja ma 30 minut.
- Odtwarzacz ma PLAY/PAUSE, pasek czasu, regulację głośności i zakończenie sesji.
- Dźwięk wychodzi przez aktualnie wybrane przez Android urządzenie audio (np. Bluetooth Zestos lub słuchawki).

PANEL OBSŁUGI
Na ekranie głównym przytrzymaj napis „MERA SPA”.
Otworzy się panel obsługi.
Dla każdego z 4 setów wybierz plik MP3/AAC/WAV zapisany na telefonie.
Aplikacja zapamięta wybrany plik po ponownym uruchomieniu telefonu.
W panelu jest też skrót do ustawień Bluetooth.

INSTALACJA / BUDOWANIE
Ten folder jest kompletnym projektem Android Studio.
1. Zainstaluj Android Studio na komputerze.
2. Wybierz Open i wskaż folder MERA_RESET_ANDROID.
3. Poczekaj na synchronizację Gradle.
4. W menu wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK pojawi się w app/build/outputs/apk/debug/app-debug.apk.
6. Prześlij APK na telefon i otwórz go, aby zainstalować aplikację.

UWAGA
Set MERA DEEP FLOW jest wbudowany w aplikację. Pozostałe sety można przypisać z poziomu panelu obsługi już na telefonie.

ALTERNATYWA BEZ ANDROID STUDIO — GITHUB ACTIONS
W projekcie jest gotowy plik .github/workflows/build-apk.yml.
Po umieszczeniu projektu w repozytorium GitHub workflow automatycznie buduje APK i zapisuje je jako artefakt MERA_RESET_APK.
