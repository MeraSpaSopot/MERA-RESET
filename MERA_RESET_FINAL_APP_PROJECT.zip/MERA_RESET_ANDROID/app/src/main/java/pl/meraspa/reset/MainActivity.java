package pl.meraspa.reset;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 7001;
    private static final long SESSION_MS = 30L * 60L * 1000L;

    private static final int BG = Color.rgb(243, 239, 232);
    private static final int CARD = Color.rgb(251, 249, 245);
    private static final int TEXT = Color.rgb(24, 48, 68);
    private static final int MUTED = Color.rgb(116, 128, 138);
    private static final int BORDER = Color.rgb(216, 208, 197);
    private static final int GOLD = Color.rgb(184, 138, 74);
    private static final int GOLD_SOFT = Color.rgb(233, 223, 208);

    private final String[] names = {
            "DEEP FLOW", "OCEAN FLOW", "VIBRO FLOW", "SACRED RESET"
    };
    private final String[] subtitles = {
            "Feel the sound", "Oceanic · spacious · flowing", "Rhythm · bass · vibration", "Meditative · deep · restorative"
    };

    private SharedPreferences prefs;
    private int pendingTrack = -1;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ProgressBar progress;
    private TextView elapsedView;
    private Button playButton;
    private long silentElapsed = 0L;
    private long silentStartedAt = 0L;
    private boolean silentRunning = false;
    private long audioElapsed = 0L;
    private long audioStartedAt = 0L;
    private boolean audioRunning = false;
    private int currentTrack = -1;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            long elapsed = getElapsedMs();
            if (progress != null) progress.setProgress((int)Math.min(elapsed, SESSION_MS));
            if (elapsedView != null) elapsedView.setText(formatTime(elapsed));
            if (elapsed >= SESSION_MS) {
                finishSession();
                return;
            }
            if (isPlayingNow()) handler.postDelayed(this, 500L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("mera_reset", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showHome();
    }

    @Override protected void onDestroy() {
        stopAndRelease();
        super.onDestroy();
    }

    private void showHome() {
        stopAndRelease();
        currentTrack = -1;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column(18);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView brand = text("MERA SPA", 12, MUTED, true);
        brand.setLetterSpacing(0.28f);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, dp(26), 0, dp(4));
        brand.setOnLongClickListener(v -> { showAdmin(); return true; });
        root.addView(brand, matchWrap());

        TextView title = text("MIND & BODY RESET", 28, TEXT, false);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.04f);
        root.addView(title, matchWrap());

        TextView intro = text("Choose your sound experience", 15, MUTED, false);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(0, dp(8), 0, dp(20));
        root.addView(intro, matchWrap());

        for (int i = 0; i < names.length; i++) {
            final int index = i;
            LinearLayout tile = makeTrackTile(names[i], subtitles[i]);
            tile.setOnClickListener(v -> openTrack(index));
            LinearLayout.LayoutParams lp = matchWrap();
            lp.setMargins(0, 0, 0, dp(12));
            root.addView(tile, lp);
        }

        TextView foot = text("BREATHE · FLOAT · RESET", 11, MUTED, true);
        foot.setLetterSpacing(0.18f);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(14), 0, dp(28));
        root.addView(foot, matchWrap());

        setContentView(scroll);
    }

    private LinearLayout makeTrackTile(String name, String subtitle) {
        LinearLayout tile = column(0);
        tile.setPadding(dp(18), dp(17), dp(18), dp(17));
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setMinimumHeight(dp(88));
        tile.setBackground(roundRect(CARD, BORDER, 1, 20));

        TextView a = text(name, 18, TEXT, true);
        TextView b = text(subtitle, 13, MUTED, false);
        b.setPadding(0, dp(5), 0, 0);
        tile.addView(a, matchWrap());
        tile.addView(b, matchWrap());
        return tile;
    }

    private void openTrack(int index) {
        if (index < 4 && getTrackUri(index) == null) {
            Toast.makeText(this, "Ten set nie ma jeszcze przypisanego pliku muzycznego.", Toast.LENGTH_LONG).show();
            return;
        }
        showPlayer(index);
    }

    private void showPlayer(int index) {
        stopAndRelease();
        currentTrack = index;
        silentElapsed = 0L;
        silentRunning = false;
        audioElapsed = 0L;
        audioRunning = false;

        LinearLayout root = column(20);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(20), dp(28), dp(20), dp(26));

        Button back = smallButton("← CHANGE EXPERIENCE");
        back.setOnClickListener(v -> showHome());
        root.addView(back, matchWrap());

        TextView kicker = text("YOUR RESET", 11, MUTED, true);
        kicker.setLetterSpacing(0.22f);
        kicker.setGravity(Gravity.CENTER);
        kicker.setPadding(0, dp(44), 0, dp(8));
        root.addView(kicker, matchWrap());

        TextView name = text(names[index], 29, TEXT, true);
        name.setGravity(Gravity.CENTER);
        root.addView(name, matchWrap());

        TextView sub = text(subtitles[index], 15, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(8), 0, dp(26));
        root.addView(sub, matchWrap());

        playButton = new Button(this);
        playButton.setAllCaps(false);
        playButton.setText("PLAY");
        playButton.setTextSize(16);
        playButton.setTextColor(TEXT);
        playButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        playButton.setBackground(roundRect(GOLD_SOFT, GOLD, 1, 28));
        playButton.setMinHeight(dp(58));
        playButton.setOnClickListener(v -> togglePlayback());
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(dp(230), dp(58));
        root.addView(playButton, playLp);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax((int)SESSION_MS);
        progress.setProgress(0);
        LinearLayout.LayoutParams progLp = matchWrap();
        progLp.setMargins(0, dp(34), 0, 0);
        root.addView(progress, progLp);

        LinearLayout timeRow = row();
        elapsedView = text("00:00", 12, MUTED, false);
        TextView total = text("30:00", 12, MUTED, false);
        timeRow.addView(elapsedView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        total.setGravity(Gravity.END);
        timeRow.addView(total, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(timeRow, matchWrap());

        TextView volumeLabel = text("VOLUME", 11, MUTED, true);
        volumeLabel.setLetterSpacing(0.15f);
        volumeLabel.setGravity(Gravity.CENTER);
        volumeLabel.setPadding(0, dp(34), 0, dp(8));
        root.addView(volumeLabel, matchWrap());

        LinearLayout vols = row();
        vols.setGravity(Gravity.CENTER);
        Button minus = smallButton("−");
        Button plus = smallButton("+");
        minus.setTextSize(24); plus.setTextSize(24);
        minus.setOnClickListener(v -> adjustVolume(AudioManager.ADJUST_LOWER));
        plus.setOnClickListener(v -> adjustVolume(AudioManager.ADJUST_RAISE));
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(76), dp(52));
        vlp.setMargins(dp(6), 0, dp(6), 0);
        vols.addView(minus, vlp);
        vols.addView(plus, vlp);
        root.addView(vols, matchWrap());

        Button end = smallButton("END SESSION");
        end.setPadding(dp(16), dp(12), dp(16), dp(12));
        end.setOnClickListener(v -> { finishSession(); showHome(); });
        LinearLayout.LayoutParams endLp = matchWrap();
        endLp.setMargins(0, dp(38), 0, 0);
        root.addView(end, endLp);

        setContentView(root);
    }

    private void togglePlayback() {
        if (player != null && player.isPlaying()) {
            audioElapsed += android.os.SystemClock.elapsedRealtime() - audioStartedAt;
            audioRunning = false;
            player.pause();
            handler.removeCallbacks(ticker);
            playButton.setText("RESUME");
            return;
        }

        if (player == null) {
            Uri uri = getTrackUri(currentTrack);
            if (uri == null) {
                Toast.makeText(this, "Brak pliku muzycznego.", Toast.LENGTH_LONG).show();
                return;
            }
            player = new MediaPlayer();
            try {
                player.setAudioStreamType(AudioManager.STREAM_MUSIC);
                player.setDataSource(this, uri);
                player.setLooping(true);
                player.prepare();
            } catch (IOException | SecurityException e) {
                stopAndRelease();
                Toast.makeText(this, "Nie mogę otworzyć tego pliku. Przypisz go ponownie w panelu obsługi.", Toast.LENGTH_LONG).show();
                return;
            }
        }
        audioStartedAt = android.os.SystemClock.elapsedRealtime();
        audioRunning = true;
        player.start();
        playButton.setText("PAUSE");
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    private long getElapsedMs() {
        return audioRunning ? audioElapsed + (android.os.SystemClock.elapsedRealtime() - audioStartedAt) : audioElapsed;
    }

    private boolean isPlayingNow() {
        return audioRunning && player != null && player.isPlaying();
    }

    private void finishSession() {
        if (player != null) {
            try { player.pause(); player.seekTo(0); } catch (Exception ignored) { }
        }
        silentRunning = false;
        silentElapsed = 0L;
        audioRunning = false;
        audioElapsed = 0L;
        handler.removeCallbacks(ticker);
        if (progress != null) progress.setProgress(0);
        if (elapsedView != null) elapsedView.setText("00:00");
        if (playButton != null) playButton.setText("PLAY");
        Toast.makeText(this, "Session complete · Breathe · Float · Reset", Toast.LENGTH_LONG).show();
    }

    private void stopAndRelease() {
        handler.removeCallbacks(ticker);
        silentRunning = false;
        silentElapsed = 0L;
        audioRunning = false;
        audioElapsed = 0L;
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            player.release();
            player = null;
        }
    }

    private void showAdmin() {
        stopAndRelease();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column(18);
        root.setPadding(dp(18), dp(24), dp(18), dp(30));
        scroll.addView(root);

        TextView title = text("MERA RESET · PANEL OBSŁUGI", 21, TEXT, true);
        root.addView(title, matchWrap());
        TextView note = text("Wszystkie cztery doświadczenia mają wbudowaną muzykę. Jeśli kiedyś zechcesz, możesz podmienić dowolny set własnym plikiem. Ustawienia są zapamiętywane w telefonie.", 14, MUTED, false);
        note.setPadding(0, dp(8), 0, dp(20));
        root.addView(note, matchWrap());

        for (int i = 0; i < 4; i++) {
            final int index = i;
            LinearLayout card = column(0);
            card.setPadding(dp(16), dp(15), dp(16), dp(15));
            card.setBackground(roundRect(CARD, BORDER, 1, 16));

            TextView n = text(names[i], 16, TEXT, true);
            TextView file = text(getTrackName(i), 13, MUTED, false);
            file.setPadding(0, dp(5), 0, dp(10));
            Button choose = smallButton("WYBIERZ PLIK MP3 / AUDIO");
            choose.setOnClickListener(v -> chooseAudio(index));
            Button clear = smallButton("USUŃ PRZYPISANIE");
            clear.setOnClickListener(v -> {
                prefs.edit().remove("uri_" + index).remove("file_" + index).apply();
                showAdmin();
            });
            card.addView(n, matchWrap());
            card.addView(file, matchWrap());
            card.addView(choose, matchWrap());
            LinearLayout.LayoutParams cl = matchWrap(); cl.setMargins(0, dp(7), 0, 0);
            card.addView(clear, cl);
            LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, 0, 0, dp(12));
            root.addView(card, lp);
        }

        Button bt = smallButton("OTWÓRZ USTAWIENIA BLUETOOTH");
        bt.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        root.addView(bt, matchWrap());

        Button back = smallButton("← WRÓĆ DO EKRANU GOŚCIA");
        back.setOnClickListener(v -> showHome());
        LinearLayout.LayoutParams blp = matchWrap(); blp.setMargins(0, dp(14), 0, 0);
        root.addView(back, blp);
        setContentView(scroll);
    }

    private void chooseAudio(int index) {
        pendingTrack = index;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null && pendingTrack >= 0) {
            Uri uri = data.getData();
            final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(uri, takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) { }
            prefs.edit().putString("uri_" + pendingTrack, uri.toString()).putString("file_" + pendingTrack, displayName(uri)).apply();
            pendingTrack = -1;
            Toast.makeText(this, "Plik przypisany.", Toast.LENGTH_SHORT).show();
            showAdmin();
        }
    }

    private Uri getTrackUri(int index) {
        String s = prefs.getString("uri_" + index, null);
        if (s != null) return Uri.parse(s);
        if (index == 0) return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mera_deep_flow);
        if (index == 1) return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mera_ocean_flow);
        if (index == 2) return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mera_vibro_flow);
        if (index == 3) return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mera_sacred_reset);
        return null;
    }

    private String getTrackName(int index) {
        String s = prefs.getString("file_" + index, null);
        if (s != null) return "Plik: " + s;
        if (index == 0) return "Wbudowany: MERA DEEP FLOW";
        if (index == 1) return "Wbudowany: MERA OCEAN FLOW";
        if (index == 2) return "Wbudowany: MERA VIBRO FLOW";
        if (index == 3) return "Wbudowany: MERA SACRED RESET";
        return "Brak przypisanego pliku";
    }

    private String displayName(Uri uri) {
        String result = "audio";
        ContentResolver cr = getContentResolver();
        try (Cursor cursor = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) { }
        return result;
    }

    private void adjustVolume(int direction) {
        AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
    }

    private String formatTime(long ms) {
        long totalSeconds = Math.max(0L, ms / 1000L);
        return String.format(Locale.US, "%02d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }

    private LinearLayout column(int sidePaddingDp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(sidePaddingDp), 0, dp(sidePaddingDp), 0);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setBackground(roundRect(CARD, BORDER, 1, 14));
        b.setMinHeight(dp(48));
        return b;
    }

    private GradientDrawable roundRect(int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onBackPressed() {
        showHome();
    }
}
